package com.projectpipeline.applicationSimplilearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationSimplilearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
