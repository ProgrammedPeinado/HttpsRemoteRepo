package com.sampledocker.finalHectorSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalHectorSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
