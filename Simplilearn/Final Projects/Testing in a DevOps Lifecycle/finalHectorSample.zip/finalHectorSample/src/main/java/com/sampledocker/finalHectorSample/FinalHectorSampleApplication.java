package com.sampledocker.finalHectorSample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalHectorSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalHectorSampleApplication.class, args);
	}

}
